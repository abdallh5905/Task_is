/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assement3_2;

/**
 *
 * @author WAY
 */
public class Mammal implements animal{
    int nooflegs;
    String FavFood;

    public Mammal(int nooflegs, String FavFood) {
        this.nooflegs = nooflegs;
        this.FavFood = FavFood;
    }

    public int getNooflegs() {
        return nooflegs;
    }

    public String getFavFood() {
        return FavFood;
    }
    
    @Override
    public void eat() {
        System.err.println("Mammal likes to eat "+ FavFood);
    }

    @Override
    public void travel() {
        
    }

}
