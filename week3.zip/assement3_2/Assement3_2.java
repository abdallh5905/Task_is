/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assement3_2;

/**
 *
 * @author WAY
 */
public class Assement3_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mammal ma= new Mammal(2, "nuts");
        System.err.println("The Favorite Food is: " + ma.getFavFood());
        System.err.println("The Number of Legs is: " + ma.getNooflegs());
    }
    
}
